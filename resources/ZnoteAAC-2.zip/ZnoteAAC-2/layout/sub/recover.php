<div class="postHolder">
	<div class="well">
		<div class="header">
			Lost Account
		</div>
		<div class="body">
			Have you lost your <a href="recovery.php?mode=username">username</a>, or your <a href="recovery.php?mode=password">password</a>?
		</div>
	</div>
</div>